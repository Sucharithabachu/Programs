package XMLProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XMLApplication {
    public static void main(String[] args) {
        SpringApplication.run(XMLApplication.class, args);
    }
}
