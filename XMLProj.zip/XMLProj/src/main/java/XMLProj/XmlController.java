package XMLProj;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class XmlController {

    @GetMapping("/processXml/{orderNo}")
    public String processXml(@PathVariable String orderNo) {
        String expectedOrderNo = "123";
        String outputXml = "<Order OrderNo=\"123\" Store=\"456\" PhoneNo=\"65767777\"/>";

        if (expectedOrderNo.equals(orderNo)) {
            return outputXml;
        } else {
            return "Order number does not match.";
        }
    }
}
